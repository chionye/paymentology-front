const Container = (props) => {

    return <div className="p-5 my-5 mx-auto">{props.children}</div>
}
export default Container;