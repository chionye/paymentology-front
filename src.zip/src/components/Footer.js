const Footer = () => {
    return(
        <footer className="bg-blue text-white text-center py-3">
            <p>Built with &hearts;</p>
        </footer>
    )
}

export default Footer;