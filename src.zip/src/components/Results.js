import Button from "./Button";
import Container from "./Container";
import FileSummary from "./FileSummary";
import Section from "./Section";
import { useFileContext } from "../context/index.context";

const Results = () => {
    const { file } = useFileContext();
    return(
        <Container>
            <Section title={"Comparison results"}>
                <div className="flex flex-col md:flex-row md:justify-between md:items-center">
                    <FileSummary 
                        fileName={file.fileName1}
                        totalRecords={450}
                        matchingRecords={420}
                        unmatchedRecords={30} 
                    />
                    <FileSummary
                        fileName={file.fileName2}
                        totalRecords={450}
                        matchingRecords={420}
                        unmatchedRecords={30} 
                    />
                </div>
                <div className="md:flex md:w-44 md:justify-center md:mx-auto">
                        <Button width={"w-full"} label={"Unmatched Report"} />
                </div>
            </Section>
        </Container>
    )
}

export default Results;